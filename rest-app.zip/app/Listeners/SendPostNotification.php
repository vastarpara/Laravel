<?php

namespace App\Listeners;

use App\Events\PostCreated;
use App\Models\Post;
use App\Models\WebsiteSubscription;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Log;

class SendPostNotification implements ShouldQueue
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param PostCreated $event
     * @return void
     */
    public function handle(PostCreated $event)
    {
        $post = $event->post;
        $post_id = $post->id;

        $new_post = Post::where('id', $post_id)->with('website.subscribers.user')->first();
        $subscribers = $new_post->website->subscribers; // all subscribers

        if ($subscribers) {
            foreach ($subscribers as $subscriber) {
                // code to send notification
                Log::info('---------------------------- POST NOTIFICATION LOG ----------------------------');
                Log::info('New Post id: ' . $new_post->id);
                Log::info('New Post title: ' . $new_post->title);
                Log::info('User Id: ' . $subscriber->user->id);
                Log::info('User Email: ' . $subscriber->user->email);
            }
        }

    }
}
