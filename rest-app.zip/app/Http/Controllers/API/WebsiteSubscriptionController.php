<?php

namespace App\Http\Controllers\API;

use App\Events\PostCreated;
use App\Http\Controllers\Controller;
use App\Models\Post;
use App\Models\User;
use App\Models\Website;
use App\Models\WebsiteSubscription;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class WebsiteSubscriptionController extends Controller
{
    public function add(Request $request)
    {
        
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|integer',
            'website_id' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 2, 'message' => 'Validation error.', $validator->errors()]);
        }

        $user_id = $request->user_id;
        $user = User::where('id', $user_id)->first();

        if (!$user)
            return response()->json(['status' => 0, 'message' => 'Please enter valid user id.']);

        $website_id = $request->website_id;
        $website = Website::where('id', $website_id)->first();
        if (!$website)
            return response()->json(['status' => 0, 'message' => 'Please enter valid website id.']);

        // if already subscribe
        $already_subscribe = WebsiteSubscription::where('user_id', $user_id)->where('website_id', $website_id)->first();
        if ($already_subscribe) {
            return response()->json(['status' => 0, 'message' => 'User already have subscription to this site.']);
        }

        $website_subscription = new WebsiteSubscription();
        $website_subscription->user_id = $user_id;
        $website_subscription->website_id = $website_id;
        if ($website_subscription->save()) {
            return response()->json(['status' => 1, 'message' => 'User has been added to subscription successfully.', 'data' => $website_subscription]);
        }

        return response()->json(['status' => 0, 'message' => 'User not added to subscription.']);
    }

    public function remove(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'user_id' => 'required|integer',
            'website_id' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 2, 'message' => 'Validation error.', $validator->errors()]);
        }

        $user_id = $request->user_id;
        $user = User::where('id', $user_id)->first();

        if (!$user)
            return response()->json(['status' => 0, 'message' => 'Please enter valid user id.']);

        $website_id = $request->website_id;
        $website = Website::where('id', $website_id)->first();
        if (!$website)
            return response()->json(['status' => 0, 'message' => 'Please enter valid website id.']);

        // if subscribe
        $have_subscribe = WebsiteSubscription::where('user_id', $user_id)->where('website_id', $website_id)->first();
        if ($have_subscribe) {
            if ($have_subscribe->delete())
                return response()->json(['status' => 1, 'message' => 'User removed from subscription successfully.', 'data' => []]);
            else
                return response()->json(['status' => 0, 'message' => 'User not removed from subscription.']);
        } else {
            return response()->json(['status' => 0, 'message' => 'No user found with subscription.']);
        }


        return response()->json(['status' => 0, 'message' => 'Something went wrong.']);
    }
}
