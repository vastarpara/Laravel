<?php

namespace App\Http\Controllers\API;

use App\Events\PostCreated;
use App\Http\Controllers\Controller;
use App\Models\Post;
use App\Models\User;
use App\Models\Website;
use App\Models\WebsiteSubscription;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class PostController extends Controller
{
    public function add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'title' => 'required|string',
            'content' => 'required|string',
            'author_id' => 'required|integer',
            'website_id' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 2, 'message' => 'Validation error.', $validator->errors()]);
        }

        $author_id = $request->author_id;
        $author = User::where('id', $author_id)->first();
        if (!$author)
            return response()->json(['status' => 0, 'message' => 'Please enter valid author id.']);

        $website_id = $request->website_id;
        $website = Website::where('id', $website_id)->first();
        if (!$website)
            return response()->json(['status' => 0, 'message' => 'Please enter valid website id.']);

        $post = new Post();
        $post->title = $request->title;
        $post->content = $request->get('content');
        $post->author_id = $author_id;
        $post->website_id = $website_id;
        if ($post->save()) {
            //Fire the event
            event(new PostCreated($post));
//            Log::info('Post Created: ' . $post);
            return response()->json(['status' => 1, 'message' => 'Post has been added successfully.', 'data' => $post]);
        }

        return response()->json(['status' => 0, 'message' => 'Post not added.']);
    }
}
