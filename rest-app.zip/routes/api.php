<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\PostController as APIPostController;
use App\Http\Controllers\API\WebsiteSubscriptionController as APIWebsiteSubscriptionController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::prefix('v1')->group(function () {
    Route::post('/addPost', [APIPostController::class, 'add'])->name('addPost');
    Route::post('/addSubscription', [APIWebsiteSubscriptionController::class, 'add'])->name('addSubscription');
    Route::post('/removeSubscription', [APIWebsiteSubscriptionController::class, 'remove'])->name('removeSubscription');
});
